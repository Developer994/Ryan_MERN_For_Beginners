import React from 'react';
import Nav from './Nav';

const App = () => (
    <div className="container pb-5">
        <Nav />
        <br />
        <h1>MERN CRUD</h1>
    </div>
);

export default App;
