exports.create = (req, res) => {
    res.json({
        data: 'hello from controllers'
    });
};
