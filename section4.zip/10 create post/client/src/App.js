import React from 'react';

const App = () => (
  <div>
    <h1>MERN CRUD</h1>
  </div>
);

export default App;
