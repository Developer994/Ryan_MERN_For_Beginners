import React from 'react';

const App = () => (
    <div className="container p-5">
        <h1>MERN CRUD</h1>
    </div>
);

export default App;
